#!/usr/bin/env python3
"""Simple, repeatable image enhancement and grading using Pillow."""
import argparse
from pathlib import Path
from PIL import Image, ImageEnhance, ImageFilter, ImageOps
import numpy as np

def grade(img, mode):
    rgb = np.asarray(img.convert("RGB")).astype(np.float32) / 255.0
    if mode == "warm":
        rgb[..., 0] *= 1.045
        rgb[..., 1] *= 1.015
        rgb[..., 2] *= 0.965
    elif mode == "cool":
        rgb[..., 0] *= 0.97
        rgb[..., 1] *= 1.005
        rgb[..., 2] *= 1.045
    elif mode == "cinematic":
        # Gentle S-curve and restrained saturation; preserve highlight detail.
        rgb = np.clip((rgb - 0.5) * 1.10 + 0.5, 0, 1)
        rgb[..., 0] *= 1.025
        rgb[..., 2] *= 0.985
    return Image.fromarray(np.uint8(np.clip(rgb, 0, 1) * 255), "RGB")

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("input", type=Path)
    p.add_argument("--mode", choices=["none", "auto", "warm", "cool", "cinematic"], default="auto")
    p.add_argument("--max-width", type=int, default=0, help="Resize proportionally; 0 keeps original size")
    p.add_argument("--sharpen", type=float, default=0.0, help="Gentle sharpening amount, 0 to 1")
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()

    if not a.input.is_file():
        p.error(f"Input file not found: {a.input}")
    if a.max_width < 0 or not 0 <= a.sharpen <= 1:
        p.error("--max-width must be >= 0 and --sharpen must be between 0 and 1")

    with Image.open(a.input) as source:
        img = ImageOps.exif_transpose(source).convert("RGB")
    original_size = img.size

    if a.mode == "auto":
        img = ImageOps.autocontrast(img, cutoff=0.5)
        img = ImageEnhance.Color(img).enhance(1.04)
        img = ImageEnhance.Contrast(img).enhance(1.04)
        img = ImageEnhance.Brightness(img).enhance(1.01)
    elif a.mode in ("warm", "cool", "cinematic"):
        img = grade(img, a.mode)

    if a.max_width and img.width > a.max_width:
        new_h = round(img.height * a.max_width / img.width)
        img = img.resize((a.max_width, new_h), Image.Resampling.LANCZOS)
    if a.sharpen:
        img = img.filter(ImageFilter.UnsharpMask(
            radius=1.2, percent=int(40 + 100 * a.sharpen), threshold=3
        ))

    a.output.parent.mkdir(parents=True, exist_ok=True)
    suffix = a.output.suffix.lower()
    if suffix in (".jpg", ".jpeg"):
        img.save(a.output, quality=94, optimize=True)
    elif suffix == ".png":
        img.save(a.output, optimize=True)
    else:
        img.save(a.output)

    print(f"Saved: {a.output}")
    print(f"Size: {original_size[0]}x{original_size[1]} -> {img.width}x{img.height}")
    print("Note: this is conventional enhancement, not AI super-resolution.")

if __name__ == "__main__":
    main()
