#!/usr/bin/env python3
"""Practical FFmpeg video grading/export helper. Requires ffmpeg and ffprobe."""
import argparse
import json
import shutil
import subprocess
from pathlib import Path

def run(args):
    return subprocess.run(args, check=True, text=True, capture_output=True)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("input", type=Path)
    p.add_argument("--mode", choices=["natural", "cinematic", "warm", "cool"], default="natural")
    p.add_argument("--aspect", choices=["keep", "9:16", "16:9", "1:1"], default="keep")
    p.add_argument("--fade", type=float, default=0.0, help="Fade-in and fade-out duration in seconds")
    p.add_argument("--crf", type=int, default=20, help="H.264 quality: lower is higher quality (18-23 recommended)")
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()

    if not a.input.is_file():
        p.error(f"Input file not found: {a.input}")
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        p.error("FFmpeg and ffprobe are required but were not found in PATH.")
    if a.fade < 0 or a.crf < 16 or a.crf > 30:
        p.error("--fade must be >= 0 and --crf must be between 16 and 30")

    probe = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                 "-of", "json", str(a.input)])
    duration = float(json.loads(probe.stdout)["format"]["duration"])

    filters = []
    if a.mode == "cinematic":
        filters.append("eq=contrast=1.08:saturation=0.94:brightness=0.005")
        filters.append("colorbalance=rs=0.025:bs=-0.015")
        filters.append("vignette=PI/5")
    elif a.mode == "warm":
        filters.append("colorbalance=rs=0.035:gs=0.012:bs=-0.025")
        filters.append("eq=saturation=1.04")
    elif a.mode == "cool":
        filters.append("colorbalance=rs=-0.025:gs=0.005:bs=0.035")

    if a.aspect != "keep":
        w, h = {"9:16": (1080, 1920), "16:9": (1920, 1080), "1:1": (1080, 1080)}[a.aspect]
        # Scale to fill then crop; user should review framing after crop.
        filters.append(f"scale={w}:{h}:force_original_aspect_ratio=increase")
        filters.append(f"crop={w}:{h}")
    else:
        filters.append("scale=trunc(iw/2)*2:trunc(ih/2)*2")

    if a.fade > 0:
        fade = min(a.fade, max(0.1, duration / 3))
        filters.append(f"fade=t=in:st=0:d={fade}")
        filters.append(f"fade=t=out:st={max(0, duration-fade)}:d={fade}")

    a.output.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["ffmpeg", "-y", "-i", str(a.input), "-vf", ",".join(filters),
           "-c:v", "libx264", "-preset", "medium", "-crf", str(a.crf),
           "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
           "-movflags", "+faststart", str(a.output)]
    run(cmd)

    if not a.output.is_file() or a.output.stat().st_size == 0:
        raise RuntimeError("FFmpeg did not create a valid output file.")
    verify = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                  "-of", "json", str(a.output)])
    out_duration = float(json.loads(verify.stdout)["format"]["duration"])
    print(f"Saved: {a.output}")
    print(f"Duration: {duration:.2f}s -> {out_duration:.2f}s")
    print(f"Mode: {a.mode}; aspect: {a.aspect}")
    print("Review the crop and color before publishing. This is not AI upscaling.")

if __name__ == "__main__":
    main()
