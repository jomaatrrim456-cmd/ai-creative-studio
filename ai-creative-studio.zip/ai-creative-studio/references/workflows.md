# Editing recipes

## Natural photo cleanup
- Correct exposure gently.
- Use modest contrast and color balance.
- Avoid aggressive clarity/sharpening.
- Preserve realistic skin and product colors.

## Cinematic photo
- Slightly deepen contrast.
- Reduce saturation only a little.
- Use a subtle cool-shadow / warm-highlight feel without tinting everything orange or blue.
- Protect highlights and keep dark detail visible.

## Gaming highlight video
- Select only the strongest moments.
- Use clean cuts and short pacing.
- Add a title only if requested.
- Keep game audio intelligible.
- Avoid excessive shake, flashes, or effects.

## Vertical social video
- Use 9:16 only when requested or when the destination requires it.
- Check that faces, captions, and key action remain inside the crop.
- If cropping would cut important content, use blurred/padded background instead.
