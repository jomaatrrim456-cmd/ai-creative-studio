# AI Creative Studio Ultimate

A Claude Skill package for guided photo and video editing workflows, with optional local Python/FFmpeg helper scripts.

## What it does
- Photo: conservative enhancement, warm/cool/cinematic grading, resize, gentle sharpening.
- Video: FFmpeg-based cinematic grade, vertical crop/pad, fade in/out, audio preservation, metadata probing.
- Workflow guidance: edit planning, pacing, color consistency, export checks, and honest capability reporting.

## Important limits
This is not a full desktop editing application and does not magically add generative AI features. The scripts perform practical, deterministic edits. True AI upscaling, object removal, background replacement, motion tracking, and advanced compositing require dedicated models or editing software. Claude must have code execution/file creation enabled and the environment must include the required tools.

## Requirements
- Python 3.9+
- Pillow and NumPy for image operations
- FFmpeg + ffprobe for video operations (must be installed separately)

Install Python dependencies:
```bash
python -m pip install -r requirements.txt
```

Check video tools:
```bash
ffmpeg -version
ffprobe -version
```

## Usage
Photo:
```bash
python scripts/image_tool.py input.jpg --mode cinematic --output output/cinematic.jpg
python scripts/image_tool.py input.jpg --mode auto --sharpen 0.4 --output output/enhanced.jpg
python scripts/image_tool.py input.jpg --mode warm --max-width 1920 --output output/warm.jpg
```

Video:
```bash
python scripts/video_tool.py input.mp4 --mode cinematic --output output/cinematic.mp4
python scripts/video_tool.py input.mp4 --aspect 9:16 --mode cinematic --output output/reel.mp4
python scripts/video_tool.py input.mp4 --mode natural --fade 0.5 --output output/clean.mp4
```

The video helper uses FFmpeg filters. It does not perform AI super-resolution or automatically invent transitions/music. Review output before publishing.

## Install as a Claude Skill
1. Keep the folder name `ai-creative-studio`.
2. Zip the folder itself so the ZIP contains `ai-creative-studio/SKILL.md`.
3. In Claude, enable Code execution and file creation if available.
4. Open Customize > Skills > Create skill > Upload a skill, then choose the ZIP.
5. Enable the skill and test with a small sample image/video.

If you want to store the project on GitHub, create a new repository named `ai-creative-studio` and upload this folder's contents. Do not mix it into an unrelated app repository.
